//  alert("Error!Please enter a valid password");
//  alert("Happy Coding!\nWelcome to JS land")
//  alert("Welcome to JS land")
//  alert("Happy coding")
//  alert("Hello.... I can run JS through my web browser's console")
 

// var userName = "Zunaira";
// alert("Welcome " + userName + "!");

// var name = "\nZunaira Naz"
// alert("Welcome"  + name + "!")

// var message ="Happy coding";
// alert(message);

// var message = "Hello world";
// alert(message);

// var name ="Zunaira"
// alert(name)

// var age = 22;
// var newAge = age-4;
// alert(newAge);

// var course = "Web and Application development";
// alert (course);

// var message = "PIZZA\nPIZZ\nPIZ\nPI\nPI";
// alert(message);

// var email = "nazzunaira63@gmail.com";
// alert(email);

// var book = "A smarter way to learn JavaScript";
// alert (book);

// document.write("yah! I can write html content through JS");

// var message ="▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬";
// alert(message);

// var Age =(18);
// alert("I am" + Age +  " years old");

// var visits = 14;
// alert("you have visited this site " + visits + " times" )

// var birthYear = 2004;
// document.write("My birth year is " + birthYear);

// var name = "John Doe";
// var quantity = 5;
// var product = "T-shirt";

// document.write(name + " ordered " + quantity + " " + product + "(s) on XYZ Clothing store");

// document .write(firstName = "John.<br>");
// document.write(lastName = "Doe.<br>");
// document.write(age ="30");

// document.write("<h1>legal</h1>")
// document.write("firstname<br>")
// document.write("Age<br>")
// document.write("favouriteColour<br>")
// document.write("_score<br>")
// document.write("$totalCost<br>")


// document.write("<h1>illegal</h1>")
// document.write("2ndPlace<br>")
// document.write("my-name<br> ")
// document.write("#count<br>")
// document.write("variable-name<br>")
// document.write("class<br>")

// document.write("<h1>Rules for naming JS variables”</h1>")
// document.write(" Variable names must start with a letter<br>")
// document.write("Avoid using reserved keywords as variable names.<br>")
// document.write("Variable names are case sensitive.<br>")
// document.write("Variable names can contain letters, numbers, underscores (_), or dollar signs ($). They cannot contain spaces or special characters such as @, !, &, etc.<br>")

// let num1 = parseInt(prompt("Enter the first number:"));
// let num2 = parseInt(prompt("Enter the second number:"));
// let sum = num1 + num2;
// document.write("The sum of " + num1 + " and " + num2 + " is " + sum);

// let num1 = parseInt(prompt("Enter the first number:"));
// let num2 = parseInt(prompt("Enter the second number:"));
// let diff = num1 - num2;
// document.write("The diff of " + num1 + " and " + num2 + " is " + diff);

// let num1 = parseInt(prompt("Enter the first number:"));
// let num2 = parseInt(prompt("Enter the second number:"));
// let mul = num1 * num2;
// document.write("The multiply of " + num1 + " and " + num2 + " is " + mul);

// let num1 = parseInt(prompt("Enter the first number:"));
// let num2 = parseInt(prompt("Enter the second number:"));
// let divide = num1 / num2;
// document.write("The div of " + num1 + " and " + num2 + " is " + divide);

// let num1 = parseInt(prompt("Enter the first number:"));
// let num2 = parseInt(prompt("Enter the second number:"));
// let modulus = num1 % num2;
// document.write("The modulus of " + num1 + " and " + num2 + " is " + modulus)

// document.write("x = 10<br>");
// document.write("var y = hello");

// let x=;
//       document.write("Value after variable declaration is: " + x);

// let x = 42;
//       document.write("The value of x is: " + x);

// let x = 5;
// document.write("Initial value: " + x);

// let x = 5;
      
// // Increment the variable
// x++;
// document.write("Value after increment is: " + x + "<br>");

// // Add 7 to the variable
// x += 7;
// document.write("Value after addition is: " + x + "<br>");

// // Decrement the variable
// x--;
// document.write("Value after decrement is: " + x + "<br>");

// // Show the remainder after dividing the variable's value by 3
// let remainder = x % 3;
// document.write("The remainder is: " + remainder + "<br>");

 // Store ticket price in a variable
//  let ticketPrice = 600;
      
 // Calculate the cost of 5 movie tickets
//  let totalCost = ticketPrice * 5;
 
 // Display the total cost in the browser
//  document.write("Total cost for 5 movie tickets is: " + totalCost + " PKR");

//   // Store ticket price in a variable
//      document.write("let ticket Price = 600<br>");
      
//       // Calculate the cost of 5 movie tickets
//      document.write("let totalCost" = ticketPrice * "5<br>");
      
//       // Display the total cost in the browser
//       document.write("Total cost for 5 movie tickets is: " + totalCost + " PKR<br>")

//  for(var i = 2; i <= 2;  i++) {
//     document.write( "Table of "+ i + " <br>" );
//     for(j = 1; j <= 10; j++){
//         document.write(i + "*"  + j + "=" + (i*j))
//         document.write("<br>")
//     }
//     document.write("<br>")
//     document.write("<br>")
 

//  document.write("Tables end here....<br>")

// // a. Store a Celsius temperature into a variable.
// document.write("let celsius= 30<br>");

// // b. Convert it to Fahrenheit & output “NNoC is NNoF”.
// document.write("let fahrenheit = (celsius * 9/5) + 32");
// document.write("${celsius}°C is ${fahrenheit}°F<br>");

// // c. Now store a Fahrenheit temperature into a variable.
// document.write("fahrenheit = 86<br>");

// // d. Convert it to Celsius & output “NNoF is NNoC”.
// document.write("celsius = (fahrenheit - 32) * 5/9<br>");
// document.write(`${fahrenheit}°F is ${celsius}°C`);

// // Store the prices and quantities of the items
// let item1Price = 10;
// let item2Price = 20;
// let item1Quantity = 3;
// let item2Quantity = 2;

// // Calculate the subtotal, shipping charges, and total
// let subtotal = item1Price * item1Quantity + item2Price * item2Quantity;
// let shippingCharges = 5;
// let total = subtotal + shippingCharges;

// // Output the results to the browser
// document.write(`<h2>Order Summary</h2>`);
// document.write(`Item 1 price: $${item1Price}<br>`);
// document.write(`Item 2 price: $${item2Price}<br>`);
// document.write(`Item 1 quantity: ${item1Quantity}<br>`);
// document.write(`Item 2 quantity: ${item2Quantity}<br>`);
// document.write(`Subtotal: $${subtotal}<br>`);
// document.write(`Shipping charges: $${shippingCharges}<br>`);
// document.write(`Total: $${total}<br>`);

// // Store total marks and marks obtained by the student
// let totalMarks = 500;
// let marksObtained = 380;

// // Calculate percentage
// let percentage = (marksObtained / totalMarks) * 100;

// // Display the result in the browser
// document.write("Total Marks: " + totalMarks + "<br>");
// document.write("Marks Obtained: " + marksObtained + "<br>");
// document.write("Percentage: " + percentage.toFixed(2) + "%");

// // Define exchange rates
// const USD_TO_PKR = 171.5;
// const SAR_TO_PKR = 45.6;

// // Calculate total amount in PKR
// let totalPKR = (10 * USD_TO_PKR) + (25 * SAR_TO_PKR);

// // Display the result in the browser
// document.write("Total amount in PKR: " + totalPKR);

// // Initialize a variable with some number
// let num = 7;

// // Perform arithmetic operations in sequence
// let result = ((num + 5) * 10) / 2;

// // Display the result in the browser
// document.write("Initial number: " + num + "<br>");
// document.write("Result: " + result);

// // Store the current year and birth year in variables
// let currentYear = new Date().getFullYear();
// let birthYear = 2004;

// // Calculate their age
// let age1 = currentYear - birthYear;
// let age2 = age1 - 1;

// // Display the result in the browser
// document.write("They are either " + age1 + " or " + age2 + " years old.");

// // Store the current year in a variable
// let currentYear = new Date().getFullYear();

// // Display the current year in the browser
// document.write("The current year is " + currentYear + ".<br>");

// // Store the birth year in a variable
// let birthYear = 2005;

// // Display the birth year in the browser
// document.write("The person's birth year is " + birthYear + ".");

// // Calculate their age
// document.write("currentYear - birthYear");

// // Store the radius in a variable
// document.write("let radius = 5");

// // Calculate the circumference and area
// let circumference = 2 * 3.142 * radius;
// let area = 3.142 * radius * radius;

// // Display the result in the browser
// document.write("The circumference is " + circumference + "<br>");
// document.write("The area is " + area);


